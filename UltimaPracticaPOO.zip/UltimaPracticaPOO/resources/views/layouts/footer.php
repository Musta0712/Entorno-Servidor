<!-- footer -->
<footer class="footer">
    <p>Desarrollo Web en Entorno Servidor</p>
    <p>Adrián Mustatea</p>
    <p>2º DAW</p>
</footer>